import Image from 'next/image'
import { Inter } from 'next/font/google'
import { dividerClasses } from '@mui/material'

const inter = Inter({ subsets: ['latin'] })

export default function Home() {
  return (
   <div>
    this is our main page
   </div>
  )
}
